#Poner al final un input para que el programa no se cierre de una.
print ("Hola Mundo")

input()
