#Poner entre comillas los datos de string
nombre = "Paul"
apellido = "Ramon"
print ("Mi nombre es :",nombre)
print ("Y mi apellido es:",apellido)
input()
