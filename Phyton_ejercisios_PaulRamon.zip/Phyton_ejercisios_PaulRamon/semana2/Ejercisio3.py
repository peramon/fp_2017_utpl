#Suma de dos numeros
numero_1 = 10
numero_2 = 15
suma = numero_1 + numero_2
print("La suma es:\t%d"%suma)
input()
