#Pequeños datos
print ("Ingrese su edad"),
edad = input()
print ("Ingrese su estatura"),
altura = input()
#Salida
#Se puede usar solo un print para la salida
print(" Mi edad es :",  edad,"\n Y mi estatura es :",  altura) 
input()
