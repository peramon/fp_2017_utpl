#variables
a = float (input("Ingrese el valor de a\n"))
b = float (input("Ingrese el valor de b\n"))
c = float (input("Ingrese el valor de c\n"))
#proceso
x = a + b + c
#salida
print ("El resultado es:\n\t",x)
input()
