#Variables
a = float (input("Ingrese el valor de a\n"))
b = float (input("Ingrese el valor de b\n"))
c = float (input("Ingrese el valor de c\n"))
#Proceso
x = ( 10 / a + b - 3 * c )
#Salida
print ("El resultado es: \n\t",x)
input()
    
