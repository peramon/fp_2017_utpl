#Variables
valor = 9
#Proceso y salida
if valor>=10 :
    print ("Aprobado con:\t",valor)
else:
    print ("Reprobado con:\t",valor)

input()
