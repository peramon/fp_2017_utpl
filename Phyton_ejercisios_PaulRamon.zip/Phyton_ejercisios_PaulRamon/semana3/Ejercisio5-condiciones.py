#Variables y enrtrada de datos
nota = float(input("Ingrese la nota del alumno\n"))
#Proceso y salida
#Se une condiciones mediante and y or
if nota >= 7 and nota <= 10 :
    print("Aprobado con:\t",nota)
else:
    print("Reprobado con:\t",nota)

input()
