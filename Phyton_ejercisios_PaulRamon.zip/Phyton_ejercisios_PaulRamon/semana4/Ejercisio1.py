#Variables y Entrada
#La opcion .title permite comenzar un string con mayuscula
nombre = input("Ingrese sus nombres:\n\t")
nombre = nombre.title()
apellido = input("Ingrese sus apellidos:\n\t")
apellido = apellido.title()
ciudad = input("Ingrese la ciudad de procedencia:\n\t")
ciudad = ciudad.title()
edad = float(input("Ingrese su edad:\n\t"))
#Procceso
x = 2017 - edad
#Salida
#Podemos transformar a x a entero directamente en la respuesta lo mis mo con edad
print ("Datos Personales\n","Nombres:",nombre,"\n Apellidos:",apellido,"\n Edad:",int(edad),"\n Año de nacimiento:",int(x),"\n Ciudad:",ciudad)

input()
