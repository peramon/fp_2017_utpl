suma = 0
bandera = True
while (bandera):
     valor = int(input("Ingrese el valor a sumar\n"))
     suma = suma + valor
     m = int(input("Ingrese -1 para salir"))
     if (m == -1) :
        bandera = False

print("Los valores sumados son:\n",suma )

input()
