#Variablex
suma = 0
suma = float(suma)
bandera = True
cadena = ""
cadena_final = ""
valor = 0
auxiliar = ("Valor ingresado:\t")
#Proceso
while (bandera) :
    valor = input("Ingrese el valor a sumar\n")
    cadena = (auxiliar + valor)+("\n")
    cadena = str(cadena)
    cadena_final = cadena_final + cadena
    valor = float(valor)
    suma = suma + valor
    m = int(input("Ingrese -1 para salir"))
    if (m == -1 ):
        bandera = False
        print("")
print(cadena_final)
suma = int(suma)
print ("Los valores sumados son:",suma)

input()
    
    
    
