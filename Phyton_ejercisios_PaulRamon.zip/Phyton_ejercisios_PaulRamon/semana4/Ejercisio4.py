#Variables
cont = 1
#Uso del ciclo repetitivo while
while cont <= 5:
    print("valor\t",cont)
    cont = cont + 1

input()
