#Variables y entrada
cont = 1
limite = int(input ("Ingrese el limite de la suma:"))

suma = 0
#Proceso
while (cont <= limite) :
    suma = suma + cont
    cont = cont + 1

print("La suma es:",suma)

input()

