#Variables
paga_final = 0
comision = 0
articulo = float(input("Ingrese los articulos vendidos de la semana-->"))
venta = float(input("Ingrese el monto vendido de los artciculos de la semana-->"))
comision = venta * 20 / 100
#Proceso              
if venta >= 5000 :
    paga_final = 200 + comision
else :
    paga_final = 200
#Salida
print ("El monto del empleado es:\n\t",paga_final)

input()
