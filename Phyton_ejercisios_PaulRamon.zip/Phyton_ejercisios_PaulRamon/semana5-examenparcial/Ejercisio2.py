#Variables
decena = 0
centenas = 0
miles = 0
cont = 1
print("N","\tN*10","\t*100","\tN*1000")
#Proceso y salida
while cont <= 6 :
    decenas = cont * 10
    centenas = cont* 100
    miles = cont * 1000
    print (cont,"\t",decenas,"\t",centenas,"\t",miles)
    cont = cont + 1

input()
