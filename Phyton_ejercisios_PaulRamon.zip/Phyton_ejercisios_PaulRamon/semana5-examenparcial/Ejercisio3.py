#Variables
numero_1 = int(input("Ingrese el primer numero-->"))
numero_2 = int(input("Ingrese el segundo numero-->"))
numero_3 = int(input("Ingrese el tercero numero-->"))
#Proceso y salida
if numero_1 > numero_3 :
    if numero_1 > numero_3 :
        print ("El numero mayor es:\n\t",numero_1)
if numero_2 > numero_1 :
    if numero_2 > numero_3 :
        print ("El numero mayor es:\n\t",numero_2)
if numero_3 > numero_1 :
    if numero_3 > numero_2 :
        print ("El numero mayor es:\n\t",numero_3)

input()
