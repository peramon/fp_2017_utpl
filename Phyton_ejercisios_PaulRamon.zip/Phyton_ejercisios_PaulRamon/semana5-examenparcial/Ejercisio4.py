#Variables
angulo1 = 0
angulo2 = 0
lado1 = 0
lado2 = 0
a1 = float(input("ingrese el angulo 1 del primer triangulo-->"))
a2 = float(input("ingrese el angulo 2 del primer triangulo-->"))
a3 = float(input("ingrese el angulo 3 del primer triangulo-->"))
l1 = float(input("Ingrese el angulo 1 del primer triangulo-->"))
l2 = float(input("Ingrese el angulo 2 del primer triangulo-->"))
l3 = float(input("Ingrese el angulo 3 del primer triangulo-->"))
a2 = float(input("ingrese el angulo 1 del segundo triangulo-->"))
a22 = float(input("ingrese el angulo 2 del segundo triangulo-->"))
a23 = float(input("ingrese el angulo 3 del segundo triangulo-->"))
l2 = float(input("Ingrese el angulo 1 del segundo triangulo-->"))
l22 = float(input("Ingrese el angulo 2 del segundo triangulo-->"))
l23 = float(input("Ingrese el angulo 3 del segundo triangulo-->"))
#Proceso y salida
angulo1 = a1 + a2 + a3
angulo2 = a2 + a22+ a23
lado1 = l1 + l2 + l3
lado2 = l2 + l22 + l23
if angulo1 == angulo2 :
    if lado1 == lado2 :
        print ("\nLos dos triangulos son congruentes")
else :
    print ("\nLos dos triangulos no son congruentes")

input()
