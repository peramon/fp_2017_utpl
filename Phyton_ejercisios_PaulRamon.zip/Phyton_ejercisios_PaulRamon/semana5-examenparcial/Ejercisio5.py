#Variables
incremento = 0
total = 0
nombre = input("Ingrese el nombre del empleado-->")
print("Ingrese el tipo de empleado-->")
print("• si es de tipo 1000 se le aumentará 1%")
print("• si es de tipo 2000 se le aumentará 2%")
print("• si es 3000, 3%")
print("• si es 4000, 4%")
print("• si es 5000, 10%")
tipo = int(input())
sueldo = float(input("Ingrese el sueldo del empleado-->"))
#Processo
if tipo == 1000 :
    incremento = sueldo * 1 /100
    total = sueldo + incremento
if tipo == 2000 :
    incremento = sueldo * 2/100
    total = sueldo + incremento
if tipo == 3000 :
    incremento = sueldo * 3 /100
    total = sueldo + incremento
if tipo == 4000 :
    incremento = sueldo * 4 /100
    total = sueldo + incremento
if tipo == 5000 :
    incremento = sueldo * 10 /100
    total = sueldo + incremento

print ("El empleado:\n",nombre.title(),"\nTiene un incremento  de :\n",incremento,"\nY un sueldo total  de:\n",total)

input()
