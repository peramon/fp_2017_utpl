suma = 0
cont = 1
cont2 = 0
numero = int(input("Ingrese el numero del que desea obtener la tabla\n"))
#Proceso
while cont <= 10 :
    suma = numero + cont 
    print( numero , "\t+" ,"\t",  cont , "\t=" , "\t", suma )
    cont = cont + 1
    

input ()
