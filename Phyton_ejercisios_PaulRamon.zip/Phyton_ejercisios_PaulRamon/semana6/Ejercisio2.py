#Ciclo for
#Aqui le hice le di una opcion para que imprima en horizontal ya que se impime
# en vertical predeterminadamente.
i = 1
print("Ingrese la opcion de salida de su respuesta:");
print("-Elija 1 para una respuesta horizontal");
print("-Elija 2 para una respuesta vertical");
opcion = int(input())
print ("")
for i in range (1,11):
    if opcion == 1 :
       print(i,end=' ')
    if opcion == 2 :
        print("\t",i)
   
input()
