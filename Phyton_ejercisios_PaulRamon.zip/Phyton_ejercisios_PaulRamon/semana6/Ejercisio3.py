#Variables
for i in range(1,11):
    print (i ,"\t", i+10)

input()
