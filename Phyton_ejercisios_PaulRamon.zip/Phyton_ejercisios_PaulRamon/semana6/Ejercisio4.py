#Variables
cadena = print("\tValor","\tTotal")
for i in range(1,11):
    print ("\t",i ,"\t", i+10)

input()
