#Variables
suma = 0
total = 0
cadena = print("\tValor","\tTotal")
for i in range(1,11):
    cadena = print ("\t",i ,"\t", i+10)
    suma = suma + i
    auxiliar = i + 10
    total = total + auxiliar
print("\t",suma,"\t",total)

input()
