#Variables
suma = 0
total = 0
numero = 0
print ("\tValor\tTotal")
for i in range(1,11):
    suma = suma + i
    numero = int(input("Ingrese el numero a sumar el contador"))
    auxiliar = i + numero
    total = total + auxiliar
    print ("\t",i,"\t",auxiliar)
print ("\n","\t",suma,"\t",total)

input()
