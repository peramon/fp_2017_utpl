#No existe el ciclo while en pythn pero se lo puede simuular
# de la siguiente forma
contador = 0
while True:
    contador = contador + 1
    print (contador)
    # Condición para romper el ciclo.
    if contador >= 10:
        break

input()
