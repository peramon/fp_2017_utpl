#Variables
contador = 1
#Ciclo do-whilw simulado
while True:
    if contador%2 == 0:
        print (contador)
    contador = contador + 1
    # Condición para romper el ciclo.
    if contador > 10:
        break

input()
