#Variabes
contador = 1
pares = 0
impares = 0
auxiliar = 0
auxiliar2 = 0
#Ciclo do-whilw simulado
print("\tpares")
while True:
    if contador%2 == 0:
        auxiliar = contador
        pares= pares + contador
        print ( "\t",auxiliar)
    contador = contador + 1
    # Condición para romper el ciclo.
    if contador > 10:
        break
print ("La suma de los pares es igual a -->",pares)
contador = 1
print("\timpares")
while True:
    if contador%2 == 1 :
        auxiliar2 = contador
        impares = impares + contador
        print ("\t" , auxiliar2)
    contador = contador + 1
    # Condición para romper el ciclo.
    if contador > 10:
        break
print ("La suma de los impares es igual a -->",impares)

input()



