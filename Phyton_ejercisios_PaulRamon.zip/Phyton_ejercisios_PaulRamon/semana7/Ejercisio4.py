opcion = 5
if (opcion !=4):
    if opcion == 1 :
        print("Lunes")
    elif opcion == 2 :
        print ("Martes")
    elif opcion == 3 :
        print("Miercoles")
    elif opcion == 4 :
        print ("Jueves")
    else:
        print("Ninguno de los anteriores")

input()
