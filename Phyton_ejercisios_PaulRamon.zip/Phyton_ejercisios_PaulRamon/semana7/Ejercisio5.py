opcion = int(input("Ingrese la opcion del dia en el que puede ir a trabajar-->"))
if (opcion != 7):
    if opcion == 1 :
        print("Lunes")
    elif opcion == 2 :
        print ("Martes")
    elif opcion == 3 :
        print("Miercoles")
    elif opcion == 4 :
        print ("Jueves")
    elif opcion == 5 :
        print ("Viernes")
    elif opcion == 6 :
        print ("Sabado")
if opcion == 7 :
    print ("Domingo")
elif opcion > 7:
    print("Ninguno de los anteriores")

input()
