dia = input("Ingrese el dia-->")
mes = int(input("Ingrese el mes-->"))
año = input("Ingrese lel año-->")
if (mes != 12) :
    if mes == 1:
        cadena = ("Enero")
    elif mes == 2:
        cadena = ("Febrero")
    elif mes == 3:
        cadena = ("Marzo")
    elif mes == 4:
        cadena = ("Abril")
    elif mes == 5:
        cadena = ("Mayo")
    elif mes == 6:
        cadena = ("Junio")
    elif mes == 7:
        cadena = ("Julio")
    elif mes == 8:
        cadena = ("Agosto")
    elif mes == 9:
        cadena = ("Septiembre")
    elif mes == 10:
        cadena = ("Octubre")
    elif mes == 11:
        cadena = ("Noviembre")
if mes == 12:
    cadena = ("Diciembre")
    
    
print("La fecha ingresada es:",dia,"de",cadena,"del",año)

input()
