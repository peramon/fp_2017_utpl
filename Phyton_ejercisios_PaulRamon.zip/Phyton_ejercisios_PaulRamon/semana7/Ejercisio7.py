nombre = input("Ingrese una cadena que empiece con vocal\n")
for letra in nombre :   
    if (letra == "a"):
        inicial = ("(a)-vocal abierta-")    
    elif (letra == "e"):
        inicial = ("(e)-vocal abierta-")      
    elif (letra == "o"):
        inicial = ("(o)-vocal abierta-")
    break
for letra in nombre :
    if (letra == "i"):
        inicial = ("(i)-vocal cerrada-")
    elif (letra == "u"):
        inicial = ("(u)-vocal cerrada-")
    break

print (" Nombre con inicial",inicial,nombre.upper())
    
input()                   
