# Juegpo para proyecto de programacion
    
import pilasengine
pilas = pilasengine.iniciar(titulo="Ovni Gunner")


class Nube_Enemigos(pilasengine.actores.Actor):

    def iniciar(self):
        self.x = self.pilas.azar(-280, 280)
        self.altura = self.pilas.azar(50, 200)
        self.imagen = "nube.png"
        self.y = self.pilas.azar(-50, 0)
        self.z = 1
        self.escala = 0.1
        self.aprender("puedeexplotar")
        #self.aprender("disparar", control=None, municion= 'MiMunicion')#, angulo_salida_disparo = pilas.azar(235,305)) #, frecuencia_de_disparo =1)
        self.vida = 10 # Hay que clicarlo 10 veces para matarlo
        pilas.utils.interpolar(self,'rotacion', 360, duracion=3)
        pilas.utils.interpolar(self, 'escala', 1.5, duracion=20)
        pilas.utils.interpolar(self, 'y', self.altura, duracion=15)
		
        self.tarea_disparar= pilas.tareas.siempre(2, self.realizar_disparo)
    
    def actualizar(self):
		if self.escala >= 0.7: #Elovni tiene un punto de mira que indica que se puede matar
			self.imagen = "nube.png"
			
		# El ovni intenta evitar nuestros disparos
		if self.vida < 7 and self.vida >2:
			pilas.utils.interpolar(self,'y', pilas.azar(-160,240), duracion =3)
			pilas.utils.interpolar(self,'x', pilas.azar(-250,250), duracion =3)		
    
    def dispararconclick(self):
		#"Se invoca cuando se hace click sobre el ovni."
        if self.vida>0:
			self.vida -=1
        
        elif self.vida <= 0:
            self.eliminar()
            self.pilas.camara.vibrar(1, 0.3)
            self.tarea_disparar.terminar()
            self.pilas.actores.Nube_Abatido(self.x, self.y)
            
    def realizar_disparo(self):
		if self.escala >= 0.8:
			#Esto hace que cada disparo tenga un angulo de tiro diferente
			self.aprender("disparar", control=None, municion= 'MiMunicion', angulo_salida_disparo = pilas.azar(250,290)) #, frecuencia_de_disparo =1)
			self.disparar()

class MiMunicion(pilasengine.actores.Actor):

    def iniciar(self):
        self.imagen = "disparos/bola_amarilla.png"
        self.escala= 0.1
        self.aprender("puedeexplotar")
    
    def actualizar(self):
        self.escala_y += 0.1
        if self.y == -140:
			self.eliminar()


class Nube_Abatido(pilasengine.actores.Actor):
	# Cuando matamos el ovni cae girando hasta tocar suelo y explotar
	def iniciar(self, x, y):
		self.imagen = "nube.png"
		self.x = x
		self.y = y
		self.transparencia = [10]		
		self.dx = self.pilas.azar(-3, 3)
		self.escala = 1.2
		self.aprender("puedeexplotar")
		
	def actualizar(self):
		self.x += self.dx
		self.y -= 3 
		self.rotacion += 3
		
		if self.y < -220:
			self.pilas.camara.vibrar(2, 0.3)
			self.eliminar()


class EscenaMenu(pilasengine.escenas.Escena):

    def iniciar(self):
        self.pilas.fondos.FondoMozaico('imagen2.png')
        actor_texto = self.pilas.actores.Actor()
        actor_texto.imagen = "click.png"
        self._aplicar_animacion(actor_texto)
        self.pilas.eventos.click_de_mouse.conectar(self._iniciar_el_juego)
        self._crear_el_titulo_del_juego()
        self._crear_indicador_creditos()
       
    
    def _aplicar_animacion(self, texto):
        texto.y = -500
        texto.escala = 4
        texto.escala = [1], 1.5
        texto.y = [-100], 1

    def _iniciar_el_juego(self, evento):
        self.pilas.escenas.EscenaJuego()

    def _crear_el_titulo_del_juego(self):
        titulo = self.pilas.actores.Actor()
        titulo.imagen = "imagen6.png"
        titulo.y = 300
        titulo.rotacion = 30
        titulo.y = [100], 1
        titulo.rotacion = [0], 1.2
        titulo.z=2

    def _crear_indicador_creditos(self):
        actor = self.pilas.actores.Actor()
        actor.imagen = "creditos.png"
        actor.x = 400
        actor.y = -160
        actor.x = [400, 400, 270], 0.5
        actor.escala = 0.5
	#pilas.avisar

class BotonVolver(pilasengine.actores.Actor):

    def iniciar(self):
        self.imagen = "boton_volver.png"
        self.cuando_hace_click = self._volver_a_la_escena_inicial
        self.y = [230]
        self.x = -270
        self.escala =0.5
        
    def _volver_a_la_escena_inicial(self, evento):
        self.pilas.escenas.EscenaMenu()


class EscenaPerdido(pilasengine.escenas.Escena):
	# Se activa cuando matan a Pingu
	def iniciar(self):
		self.pilas.fondos.FondoMozaico('azul1.png')
		pilas.actores.BotonVolver()
		pingu=pilas.actores.Pingu()
		pingu.y=-200
		pingu.escala= 3
		pingu.aprender("puedeexplotar")
		pingu.decir("No me dieronl!!!")
		pilas.tareas.agregar(5, pingu.eliminar)
		pilas.avisar("Lo siento, perdiste...")
		
class EscenaJuego(pilasengine.escenas.Escena):
	#Escena principal del juego

	def _crear_un_ovni(self):
		self.pilas.actores.Nube_Enemigos()
		#pilas.avisar("Enemigo localizado")
	
	def _cuando_hace_click(self, evento):
		explosion = pilas.actores.Animacion(imagen_explosion)
		explosion.escala = 0.5
		explosion.x = evento.x
		explosion.y = evento.y
		sonido_explosion.reproducir()
		
		#obtenemos las colisiones con el mouse	
		colisiona = self.obtener_actores_en(evento.x, evento.y)
		for actor in colisiona:
			if isinstance(actor, Nube_Enemigos):
					if actor.escala >= 0.6:
						actor.dispararconclick()
					else:
						None
						#print("No se puede")
	
	def findejuego(self):
		self.pilas.escenas.EscenaPerdido()
	
	
	def iniciar(self):
		self.fondo = pilas.fondos.Tarde()
		self._crear_boton_volver()
		pingu = pilas.actores.Pingu(y= -240)
		pingu.escala =0.5
		pingu.aprender('limitadoabordesdepantalla')
		                 
		pilas.tareas.siempre(4, self._crear_un_ovni)
		pingu.decir("ES hora de freirlos!!!")
		pilas.eventos.click_de_mouse.conectar(self._cuando_hace_click)
		
		pilas.colisiones.agregar('pingu','MiMunicion',self.findejuego)
		pilas.colisiones.agregar('pingu','Nube_Abatido',self.findejuego)

	def _crear_boton_volver(self):
		pilas.actores.BotonVolver()


imagen_explosion = pilas.imagenes.cargar_grilla("explosion.png", 7)
sonido_explosion = pilas.sonidos.cargar("explosion.wav")
		
## Vinculamos todas las escenas.
pilas.escenas.vincular(EscenaMenu)
pilas.escenas.vincular(EscenaJuego)
pilas.escenas.vincular(EscenaPerdido)

## Vinculamos los actores Personalizados
pilas.actores.vincular(BotonVolver)
pilas.actores.vincular(MiMunicion)
pilas.actores.vincular(Nube_Enemigos)
pilas.actores.vincular(Nube_Abatido)


# Se inicia la escena principal.
pilas.escenas.EscenaMenu()
pilas.ejecutar()
