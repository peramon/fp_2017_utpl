
""" Imprime arreglo bidimensional en blanco"""
arreglo = [[1, 2, 3], [11, 22, 33]]
for i in range(1):
	for j in range(1):
		print(arreglo[0],"\n",arreglo[1])
	
	
input()

