class Operaciones1:
    def sumar(self,a,b):
        suma = a + b
        print("La suma es: ",suma)
    def restar(self,a,b):
        resta = a - b
        print("La resta es: ",resta)
    def multiplicar(self,a,b):
        multiplica = a * b
        print("La multiplicacion es: ",multiplica)
    def dividir(self,a,b):
        divide = a / b
        print("La division es: ",divide)
    def ope(self,tipo,a,b):
         if tipo == 1 :
             self.sumar(a,b)
         if tipo == 2 :
             self.restar(a,b)
         if tipo == 3 :
             self.multiplicar(a,b)
         if tipo == 4 :
             self.dividir(a,b)

    


    
