class Presenta1:
    def mayusculas(self,nombre):
        print("Nombre Ingresaado: ",nombre.upper())
    def minusculas(self,nombre):
        print("Nombre Ingresado: ",nombre.lower())
    def presentar(self,opcion,nombre):
        if opcion == 1 :
            self.mayusculas(nombre)
        if opcion == 2 :
            self.minusculas(nombre)
        if opcion > 2:
            print("No hay reporte")
                    
            
