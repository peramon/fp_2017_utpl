from Presenta import Presenta1
imprimir = Presenta1()
nombre = input("Ingrese su nombre-->")
print("Tipo de reporte: 1(Mayusculas)----2(Minusculas)")
opcion = int(input())
imprimir.presentar(opcion,nombre)

     

