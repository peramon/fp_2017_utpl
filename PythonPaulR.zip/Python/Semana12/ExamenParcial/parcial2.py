# Ejercisio 1
estudiantes, mayor, promedio, tot = 0, 0, 0, 0
calif = [0,0,0,0,0,0,0]
estudiantes = int(input("Cantidad de estudiantes: "))
j=1
suma = 0
for i in range(0, estudiantes ):
	calif[i] = (input("Ingrese la nota del estudiante" ))
	suma = suma + int(calif[i])
	j = j + 1
for i in range(0, estudiantes ):
        
	if(int(calif[i]) > int(calif[i+1])):
		mayor = calif[i]
	# if(calif[i] == calif[i+1]):
		# mayor = calif[i]	
	# tot = tot + int(calif[i])
print("La mayor nota es: " , mayor)
promedio = suma / estudiantes
print("El promedio es:  " , promedio)
if(promedio >= 90):
	print("El estudiante tiene sobresaliente")
if(promedio >= 70 and promedio < 90):
	print("El estudiante tiene un resultado muy bueno")
if(promedio >= 45 and promedio < 70):
	print("El estudiante es bueno")
if(promedio <= 45):
	print("El estudiante tiene un resultado regular")

input()




