class Estudiante:
    nombre = ""
    edad = 0
# Metodo para agregar el  nombre
    def agregar_nombre(self,n):
        self.nombre = n
# Metodo para obttener el nombre
    def obtener_nombre(self):
        return nombre
    def agregar_edad(self,edad):
        if (edad<=18):
            self.edad = 18
        else:
            self.edad = self.edad
    def obtener_edad(self):
        return self.edad

# input()
