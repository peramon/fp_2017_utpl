# Arreglos unidimensionales o Listas

lista = [0,0,0,0,0]
i = 0
for number in lista:
    print ("Posición",lista[0],"- Valor",i)
    lista[0] = lista[0] + 1

input()

