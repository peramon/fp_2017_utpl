# Variables
suma = 0
promedio = 0
dias=["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
respuesta=[0,0,0,0,0,0,0]
# Proceso y  salida
for i in range (7):
    respuesta[i] = input("Ingrese el numero de partidos jugados el dia " + dias[i]+"--->")
    suma = suma + int(respuesta[i])

for i in range (7):
    print("Partidos jugados el dia "+dias[i]+"fue "+respuesta[i])
promedio = (float(suma / 7))

print("El promedio de partidos jugados es: "+ str(promedio))
input()
