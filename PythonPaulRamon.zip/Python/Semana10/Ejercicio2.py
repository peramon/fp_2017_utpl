# Semana 2
# Imprime arreglo bidimensional en blanco
# Arreglos bidimensionales

arreglo = [0,0,0,0]
for i in range( 4):
	print(arreglo)
	print()



input()
