# Semana 2
# Imprime arreglo bidimensional en blanco
# Arreglos bidimensionales

arreglo = [[0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0]]
for i in range(0, 4):
	for j in range(0, 4):
		print(arreglo[i][j])
	print()

input()


