# Ejercicio para obtener promedio

notas = [[7, 7, 8], [9,8,10],[10,10,3]]
for i in range(0, 3):
		promedio = 0
		suma = 0
		for j in range(0, 3):
			suma = suma + notas[i] [j]
			print( notas[i] [j])
		promedio = suma / 3
		print("Promedio %.2f\n" % promedio)

