from Presenta import Presenta1
p = Presenta1()
nombre = input("Ingrese su nombre-->")
print("Tipo de reporte: 1(Mayusculas)----2(Minusculas)")
opcion = int(input())
if opcion == 1 :
        p.mayusculas(nombre)
if opcion == 2 :
        p.minusculas(nombre)
if opcion > 2:
        print("No hay reporte")
                    
            




