class Ciudad1:
    nombre = ""
    poblacion_hombres = 0
    poblacion_mujeres = 0
    poblacion = 0
    
    def agregar_nombre(self,n):
        self.nombre = n
    def obtener_nombre(self):
        return nombre

    def agregar_poblacion_mujeres(self, n):
        self.poblacion_mujeres = n
    def obtener_poblacion_mujeres(self):
        return self.poblacion_mujeres;

    def agregar_poblacion_hombres(self, n):
        self.poblacion_hombres = n;
    def obtener_poblacion_hombres():
        return self.poblacion_hombres;

    def obtener_poblacion(self):
        poblacion  = 0
        self.poblacion = self.poblacion_hombres + self.poblacion_mujeres
        return self.poblacion
        
  
