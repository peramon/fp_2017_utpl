from Estudiante import Estudiante

es1 = Estudiante()
es2 = Estudiante()

suma_edades = 0
promedio = 0

es1.nombre = "Luis"
es2.nombre = "Maria"

es1.edad = 18
es2.edad = 17

suma_edades = es1.edad + es2.edad
promedio = (float(suma_edades)/2)

print (promedio)

input ()
