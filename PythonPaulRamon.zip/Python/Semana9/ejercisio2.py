# Arreglos unidimensionales o Listas

lista = [11,22,43,14]
i = 0
j = 0
suma = 0
for i in range(4):
    print ("Posición",j,"- Valor",lista[i])
    suma = lista[i] + suma
    i = i + 1
    j = j + 1
print(suma)
input()
