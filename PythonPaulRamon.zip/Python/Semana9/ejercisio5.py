
rangos = ["<18", ">=18&&<=25", ">25"]
valores = [0,0,0]
opcion = 0
limite = 0

limite=int(input("Ingrese las veces que desea ingresar la edad-->"))

for i in range (limite):
    edad = int(input("Ingrese la edad del alumno")
    if edad < 18: 
        valores[0] = valores[0] + 1
    if edad >= 18 and edad <= 25 :
        valores[1] = valores[1] + 1
    if edad > 25:
        valores[2] = valores[2] + 1
    opcion = int(input("Desea ingresar mas edades:\n1 = SI\n2 = NO")

for i in range(limite):
    print("El rango de estudiantes que ingreso de: "+rangos[i]+"es: "+valores[i])
 
