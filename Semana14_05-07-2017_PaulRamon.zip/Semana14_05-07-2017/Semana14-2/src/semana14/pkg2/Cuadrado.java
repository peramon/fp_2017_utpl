/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semana14.pkg2;

/**
 *
 * @author Usuario
 */
public class Cuadrado {

    // Atributo
    private int lado;

    // Métodos
    // Método para agregar el lado del cuadrado
    public void agregar_lado(int l) {
        lado = l;
    }

    // Método para obtener el lado del cuadrado
    public int obtener_lado() {
        return lado;
    }

    // Método para calcular el area del cuadrado
    public int calcular_area() {
        int area = lado * lado;
        // int area2  = obtener_lado() * obtener_lado();
        return area;
    }

    // Método para obtener perimetro del cuadrado
    public int calcular_perimetro() {
        int perimetro = lado + lado + lado + lado;
        // int perimetro2  = obtener_lado() + obtener_lado()+obtener_lado() + obtener_lado();
        return perimetro;
    }
}
