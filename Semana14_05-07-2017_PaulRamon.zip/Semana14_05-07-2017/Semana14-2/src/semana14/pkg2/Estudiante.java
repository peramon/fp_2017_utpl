/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semana14.pkg2;

/**
 *
 * @author Usuario
 */
public class Estudiante {

    // Atributos
    private String nombre;
    private int edad;

    // Creamos métodos para poder usar los atributos
    // Metodo para agregar el  nombre
    
    public void agregar_nombre(String n) {
        nombre = n;
    }

    // Metodo para obttener el nombre
    public String obtener_nombre() {
        return nombre;
    }

    public void agregar_edad(int e) {
        if(e<18){
            edad = 18;
        }else{
        edad = e;
        }
    }

    public int obtener_edad() {
        return edad;
    }

}
