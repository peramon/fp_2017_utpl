/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semana14.pkg2;

/**
 *
 * @author Usuario
 */
public class Principal {

    public static void main(String[] args) {
        Estudiante es1 = new Estudiante();
        Estudiante es2 = new Estudiante();
        int suma_edades = 0;
        double promedio = 0;

        // es1.nombre = "Luis";
        // es2.nombre = "Maria";
        String valor_nombre = "Luis";
        es1.agregar_nombre(valor_nombre);

        // es1.edad = 18;
        // es2.edad = 17;
        //int valor_edad = 18;
        es1.agregar_edad(18);
        //valor_edad = 17;
        es2.agregar_edad(17);

        // suma_edades = es1.edad + es2.edad;
        suma_edades = es1.obtener_edad() + es2.obtener_edad();
        promedio = (double) suma_edades / 2;

        System.out.println(promedio);
    }
}
