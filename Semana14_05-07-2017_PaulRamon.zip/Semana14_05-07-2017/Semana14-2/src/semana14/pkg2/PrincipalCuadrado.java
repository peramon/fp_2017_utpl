/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semana14.pkg2;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class PrincipalCuadrado {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int la;
        // Usamos un for para crear 4 objetos
        for (int i = 0; i <= 5; i++) {
            Cuadrado c = new Cuadrado();
            System.out.println("---------------------------------");
            System.out.println("Ingrese el lado del cuadrado");
            la = entrada.nextInt();
            c.agregar_lado(la);
            c.calcular_area();
            c.calcular_perimetro();
            int area = c.calcular_area();
            int perimetro = c.calcular_perimetro();
            // System.out.printf("El cuadrado con lado: %d\n\tArea= %d\n\tPermetro= %d\n",
            //       c.obtener_lado(), c.calcular_area(), c.calcular_perimetro());
            System.out.printf("El cuadrado con lado: %d\n\tArea= %d\n\tPermetro= %d\n",
                 la, area, perimetro);

        }

    }
}
