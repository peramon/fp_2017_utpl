/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semana14;

/**
 *
 * @author Usuario
 */
public class Principal {

    public static void main(String[] args) {
        // Creamos los objetos
        Estudiante es1 = new Estudiante();
        Estudiante es2 = new Estudiante();
        // Variables
        int suma_edades = 0;
        double promedio = 0;
        // Llamamos a los atributos
        es1.nombre = "Luis";
        es2.nombre = "Maria";
        
        es1.edad = 18;
        es2.edad = 17;
        // Procesos
        suma_edades = es1.edad + es2.edad;
        promedio = (double)suma_edades / 2;
        // Salida
        System.out.println(promedio);
    }

}
